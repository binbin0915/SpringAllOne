package com.southwind.entity;

import lombok.Data;

@Data
public class Address {
    private Integer code;
    private String value;
}
